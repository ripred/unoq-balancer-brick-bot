#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/applab_layout_probe/sketch/sketch.ino"
#line 1 "/home/arduino/ArduinoApps/applab_layout_probe/sketch/sketch.ino"
void setup();
#line 6 "/home/arduino/ArduinoApps/applab_layout_probe/sketch/sketch.ino"
void loop();
#line 1 "/home/arduino/ArduinoApps/applab_layout_probe/sketch/sketch.ino"
void setup() {
  // put your setup code here, to run once:

}

void loop() {
  // put your main code here, to run repeatedly:

}

