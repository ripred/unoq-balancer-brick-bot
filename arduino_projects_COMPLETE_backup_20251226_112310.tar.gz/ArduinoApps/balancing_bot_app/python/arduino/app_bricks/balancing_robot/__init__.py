"""Balancing robot brick API + simulation."""

import random
import threading
import time
from typing import Any, Dict, Optional


class BalancingRobot:
    def __init__(self, imu_model: str = "mpu6050", simulated: bool = True, update_hz: int = 15):
        self.imu_model = imu_model
        self.simulated = simulated
        self.update_hz = update_hz

        self.pid = {"p": 12.0, "i": 0.0, "d": 0.4}
        self.setpoint = 0.0
        self._integral = 0.0
        self._last_error = 0.0

        self._telemetry: Dict[str, Any] = {
            "ts": 0.0,
            "angle_deg": 0.0,
            "gyro_dps": 0.0,
            "accel_g": 0.0,
            "pid": self.pid.copy(),
            "setpoint": self.setpoint,
            "motor_pwm": {"left": 0, "right": 0},
            "encoders": {"left": 0, "right": 0},
            "mode": "sim" if self.simulated else "real",
            "imu_model": self.imu_model,
        }

        self._ui = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

    def attach_webui(self, ui) -> None:
        self._ui = ui
        ui.on_connect(lambda sid: self._send_config(sid))
        ui.on_message("get_initial_state", self._on_get_initial_state)
        ui.on_message("set_pid", self._on_set_pid)
        ui.on_message("set_setpoint", self._on_set_setpoint)
        ui.on_message("set_imu_model", self._on_set_imu_model)
        ui.on_message("set_mode", self._on_set_mode)
        ui.on_message("kick", self._on_kick)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)

    def get_state(self) -> Dict[str, Any]:
        return {
            "config": {
                "imu_model": self.imu_model,
                "pid": self.pid.copy(),
                "setpoint": self.setpoint,
                "mode": "real" if not self.simulated else "sim",
            },
            "telemetry": self._telemetry,
        }

    # HTTP setters for polling mode
    def http_set_pid(self, p=None, i=None, d=None) -> Dict[str, Any]:
        data = {"p": p, "i": i, "d": d}
        self._on_set_pid(None, data)
        return self.get_state()["config"]

    def http_set_setpoint(self, setpoint=None) -> Dict[str, Any]:
        self._on_set_setpoint(None, {"setpoint": setpoint})
        return self.get_state()["config"]

    def http_set_imu_model(self, imu_model=None) -> Dict[str, Any]:
        self._on_set_imu_model(None, {"imu_model": imu_model})
        return self.get_state()["config"]

    def http_set_mode(self, mode=None) -> Dict[str, Any]:
        self._on_set_mode(None, {"mode": mode})
        return self.get_state()["config"]

    def http_kick(self, angle=None) -> Dict[str, Any]:
        self._on_kick(None, {"angle": angle})
        return self.get_state()["config"]

    def _send_config(self, client=None) -> None:
        if not self._ui:
            return
        self._ui.send_message("config", self.get_state()["config"], client)

    def _on_get_initial_state(self, client, _data) -> None:
        self._send_config(client)

    def _on_set_pid(self, _client, data) -> None:
        try:
            if data.get("p") is not None:
                self.pid["p"] = float(data.get("p"))
            if data.get("i") is not None:
                self.pid["i"] = float(data.get("i"))
            if data.get("d") is not None:
                self.pid["d"] = float(data.get("d"))
        except (ValueError, TypeError):
            return
        self._send_config()

    def _on_set_setpoint(self, _client, data) -> None:
        try:
            if data.get("setpoint") is not None:
                self.setpoint = float(data.get("setpoint"))
        except (ValueError, TypeError):
            return
        self._send_config()

    def _on_set_imu_model(self, _client, data) -> None:
        model = data.get("imu_model")
        if model:
            self.imu_model = str(model)
            self._send_config()

    def _on_set_mode(self, _client, data) -> None:
        mode = str(data.get("mode", "sim"))
        self.simulated = (mode != "real")
        self._send_config()

    def _on_kick(self, _client, data) -> None:
        try:
            angle = float(data.get("angle", 30))
        except (ValueError, TypeError):
            angle = 30.0
        # Hard shove: set telemetry to a large angle with some rate
        self._telemetry["angle_deg"] = angle
        self._telemetry["gyro_dps"] = 5.0 if angle >= 0 else -5.0

    def _run_loop(self) -> None:
        dt = 1.0 / max(1, int(self.update_hz))
        angle = 12.0
        rate = 0.0
        enc_l = 0
        enc_r = 0

        while not self._stop.is_set():
            if self.simulated:
                # Larger, slower oscillation with noise for visible UI motion.
                rate += (-0.25 * angle - 0.03 * rate + random.uniform(-0.5, 0.5))
                angle += rate * dt
            else:
                # Placeholder for real IMU reads (to be wired later)
                angle += 0.0
                rate *= 0.95

            # Inject any external kicks from _telemetry
            if abs(self._telemetry.get("angle_deg", 0.0) - angle) > 20.0:
                angle = self._telemetry.get("angle_deg", angle)
                rate = self._telemetry.get("gyro_dps", rate)

            error = self.setpoint - angle
            self._integral += error * dt
            deriv = (error - self._last_error) / dt
            self._last_error = error

            pid_out = (
                self.pid["p"] * error
                + self.pid["i"] * self._integral
                + self.pid["d"] * deriv
            )
            pid_out = max(-255.0, min(255.0, pid_out))

            # Simulated encoders proportional to output.
            enc_l += int(pid_out * 0.12)
            enc_r += int(pid_out * 0.12)

            self._telemetry = {
                "ts": time.time(),
                "angle_deg": angle,
                "gyro_dps": rate,
                "accel_g": max(-2.0, min(2.0, angle / 10.0)),
                "pid": self.pid.copy(),
                "setpoint": self.setpoint,
                "motor_pwm": {"left": int(pid_out), "right": int(pid_out)},
                "encoders": {"left": enc_l, "right": enc_r},
                "mode": "real" if not self.simulated else "sim",
                "imu_model": self.imu_model,
            }

            if self._ui:
                self._ui.send_message("telemetry", self._telemetry)

            time.sleep(dt)
