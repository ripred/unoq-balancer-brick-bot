"""Balancing robot brick API (placeholder)."""

class BalancingRobot:
    def __init__(self, imu_model="mpu6050"):
        self.imu_model = imu_model

    def start(self):
        pass

    def stop(self):
        pass
