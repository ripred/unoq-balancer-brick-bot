from arduino.app_utils import App
from arduino.app_bricks.balancing_robot import BalancingRobot

bot = BalancingRobot(imu_model="mpu6050", simulated=True, update_hz=15)

bot.start()
App.run()
